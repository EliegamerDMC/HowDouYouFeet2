function mostrarSeccion(id) {
    // Ocultar todas las secciones
    const secciones = document.querySelectorAll('.seccion');
    secciones.forEach(seccion => seccion.classList.remove('visible'));

    // Mostrar la sección seleccionada
    const seccionSeleccionada = document.getElementById(id);
    seccionSeleccionada.classList.add('visible');
}

// Mostrar el apartado "Inicio" por defecto al cargar la página
document.addEventListener('DOMContentLoaded', function () {
    mostrarSeccion('inicio');
});
function mostrarSeccion(id) {
    // Ocultar todas las secciones
    const secciones = document.querySelectorAll('.seccion');
    secciones.forEach(seccion => {
        seccion.classList.remove('visible');
        seccion.classList.remove('fade-in'); // Remover la animación anterior
    });

    // Mostrar la sección seleccionada con animación
    const seccionSeleccionada = document.getElementById(id);
    seccionSeleccionada.classList.add('visible');
    seccionSeleccionada.classList.add('fade-in'); // Añadir la clase de animación

    // Remover el estado activo de todos los enlaces
    const enlaces = document.querySelectorAll('nav ul li a');
    enlaces.forEach(enlace => enlace.classList.remove('active'));

    // Añadir el estado activo al enlace clicado
    const enlaceActivo = document.querySelector(nav ul li a[href="#${id}"]);
    enlaceActivo.classList.add('active');
}

// Mostrar el apartado "Inicio" por defecto al cargar la página
document.addEventListener('DOMContentLoaded', function () {
    mostrarSeccion('inicio');
});